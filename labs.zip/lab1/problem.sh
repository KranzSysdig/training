#!/bin/sh

#rand_scale=`shuf -i 10-20 -n 1`
kubectl scale -n voting-app --replicas=${rand_scale} deployment/voter > /dev/null 2>&1
kubectl scale -n voting-app --replicas=${rand_scale} deployment/worker > /dev/null 2>&1
